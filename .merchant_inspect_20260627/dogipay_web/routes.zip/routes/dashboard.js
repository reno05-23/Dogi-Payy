const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { isAuthenticated } = require('../middleware/auth');

// GET /dashboard
router.get('/dashboard', isAuthenticated, async (req, res) => {
  try {
    const merchantId = req.session.merchant.id;

    // Total top-up hari ini
    const [todayTopup] = await db.query(`
      SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count
      FROM topup_transactions
      WHERE merchant_id = ? AND DATE(created_at) = CURDATE() AND status = 'success'
    `, [merchantId]);

    // Total customer aktif
    const [activeUsers] = await db.query(`
      SELECT COUNT(*) as count FROM users WHERE is_active = 1
    `);

    // Total top-up bulan ini
    const [monthTopup] = await db.query(`
      SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count
      FROM topup_transactions
      WHERE merchant_id = ? AND MONTH(created_at) = MONTH(CURDATE()) AND status = 'success'
    `, [merchantId]);

    // Transaksi terbaru (10 terakhir)
    const [recentTransactions] = await db.query(`
      SELECT t.*, u.name as customer_name, u.phone as customer_phone
      FROM topup_transactions t
      JOIN users u ON t.user_id = u.id
      WHERE t.merchant_id = ?
      ORDER BY t.created_at DESC
      LIMIT 10
    `, [merchantId]);

    res.render('dashboard', {
      title: 'Dashboard - DogiPay',
      merchant: req.session.merchant,
      success: req.flash('success'),
      error: req.flash('error'),
      stats: {
        todayTotal: todayTopup[0].total,
        todayCount: todayTopup[0].count,
        activeUsers: activeUsers[0].count,
        monthTotal: monthTopup[0].total,
        monthCount: monthTopup[0].count,
      },
      recentTransactions
    });
  } catch (err) {
    console.error(err);
    res.render('dashboard', {
      title: 'Dashboard - DogiPay',
      merchant: req.session.merchant,
      success: [],
      error: ['Gagal memuat data'],
      stats: { todayTotal: 0, todayCount: 0, activeUsers: 0, monthTotal: 0, monthCount: 0 },
      recentTransactions: []
    });
  }
});

module.exports = router;
